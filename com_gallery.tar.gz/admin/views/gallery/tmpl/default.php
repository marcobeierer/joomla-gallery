<?php defined('_JEXEC') or die('Restricted access'); ?>

<p>Nothing to do here</p>